﻿using UnityEngine;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

[Flags]
public enum cubeFlags
{
    cf_none             = 0,
    cf_immovable        = 1 << 0,
    cf_physicalizable   = 1 << 1,
    cf_background       = 1 << 2
}
public enum cubeMaterial
{
    grass,rock,sand,air,water,bedrock
}


public struct cube
    {
        public cubeFlags    flags;
        public uint         id;
        public uint         chunkPosition;
        public Mesh         geometry;
        public Material     material;

    }
public struct ChunkData
    {
        public Vector2 worldPos;
        public int localChunkId;
        public bool active;
        public List<cube> cubes;
    }
public class Chunk
{
    private uint Totalcubes = 0;

    

    Chunk()
    {
       
    }
    ~Chunk(){ }
    void Addcube()
    {

    }
   

}

