﻿using UnityEngine;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


public class TerrainSystem
{
    private uint tileCount = 0;
    public List<Chunk> chunks;

    TerrainSystem()
    {

    }
    ~TerrainSystem()
    {

    }
    public uint GetTileCount()
    {
        return tileCount;
    }
    public uint AddTile()
    {
        return tileCount += 1;
    }
}

