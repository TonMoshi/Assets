﻿using System;
using UnityEngine;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using System.IO;


class FileIO : MonoBehaviour
{
   static string chuckFileSTD = "chunkData.ck";
    public static string gameLevelFolder = Application.dataPath + "/levels/";
    

    public static void createFolder(string folderName)
    {
       if(!Directory.Exists(gameLevelFolder + folderName))
        {
            Directory.CreateDirectory(gameLevelFolder + folderName);
        }
    }
    public void writeeChunkData(string actualLevel)
    {
        string data = null;

        int chunkRow = 210;
        int chunkCol = 50;
       
            StreamWriter sw = new StreamWriter(gameLevelFolder+actualLevel + "/" + chuckFileSTD, true);
            
            sw.WriteLine("Line 2");
            System.Random rnd = new System.Random();
        
        for (int i = 0; i < chunkRow; i++)
        {
            for (int e = 0; e < chunkCol; e++)
            {
                //data += "\n!";
                for (int o = 0; o < 520; o++)
                {
                    

                   // int randomNumber = rnd.Next(0, 25); // creates a number

                   // data += randomNumber.ToString() + ",";
                    sw.WriteLine("Hello World");
                }
               // data = data.Remove(data.Length - 1);
            }
        }
        //Now dump the data in the file
        if (!Directory.Exists(gameLevelFolder + actualLevel))
        {
            Directory.CreateDirectory(gameLevelFolder + actualLevel);
        }
        sw.Close();
      //  File.WriteAllText(gameLevelFolder + actualLevel +"/"+ chuckFileSTD, data);
    }

    IEnumerator writeChunkData(string actualLevel)
    {
        string data = null;

        int chunkRow = 210;
        int chunkCol = 50;
      
       // StreamWriter sw = new StreamWriter(gameLevelFolder + actualLevel + "/" + chuckFileSTD, true);
        FileStream stream = new FileStream(gameLevelFolder + actualLevel + "/" + chuckFileSTD, FileMode.Create, FileAccess.Write);
        BinaryWriter writer = new BinaryWriter(stream);

        
        
        System.Random rnd = new System.Random();

        byte randomNumber = 0;
        //byte[520] numbers;
        

        for (int i = 0; i < chunkRow; i++)
        {
            for (int e = 0; e < chunkCol; e++)
            {
                //data += "\n!";
                for (int o = 0; o < 520; o++)
                {
                    
                    // data a ser guardada
   
                    randomNumber =Convert.ToByte(rnd.Next(0, 255)); // creates a number
                    writer.Write(randomNumber);
                    
                    // data += randomNumber.ToString() + ",";
                    //sw.Write(randomNumber+",");
                }
                // data = data.Remove(data.Length - 1);
                //sw.Write("\n");
            }
        }
        //Now dump the data in the file
        if (!Directory.Exists(gameLevelFolder + actualLevel))
        {
            Directory.CreateDirectory(gameLevelFolder + actualLevel);
        }
        writer.Close();
        stream.Close();
        //sw.Close();
        //  File.WriteAllText(gameLevelFolder + actualLevel +"/"+ chuckFileSTD, data);
        yield return null;
    }

    //public static void readChunkData(string actualLevel)
    //{
    //    StreamReader source = new StreamReader(gameLevelFolder + actualLevel + chuckFileSTD);
    //    string[] chunk = source.ToString().Split("!"[0]);
    //    for(int i=0; i < chunk.Length;i++)
    //    {
    //        ChunkData ckData ;
    //        ckData.active = false;
    //        ckData.localChunkId = i;
    //        ckData.worldPos = new Vector3(0+(i * 20),0+(i*26),0);
    //        for (int e = 0; e < )
    //        {

    //        }
    //        ckData.cubes.Add()
    //    }
    //  //  uint [] chunkData = source.ToString().Split("!"[0]);
    //}

    public static void readFile()
    {
        StreamReader source = new StreamReader(Application.dataPath + "/" + chuckFileSTD);
        string filecontent = source.ReadToEnd();
        source.Close();
        var tileArray = filecontent.Split("!"[0]);
        foreach(var tile in tileArray)
        {
            Debug.LogWarning(tile);
        }
    }
    //The last "/" between the file and the path shouldn't be used
    public static void doBackupFile(bool delete, string actualLevel = "0")
    {
        if(actualLevel == "0")
        {
            actualLevel = gameLevelFolder+ actualLevel;
        }else
        {
            actualLevel = gameLevelFolder+ actualLevel + "/";
        }

        string filenameWithoutExtension = Path.GetFileNameWithoutExtension(chuckFileSTD);

        string OriginalFile = actualLevel + filenameWithoutExtension + ".ck";
        string FileToReplace = actualLevel + filenameWithoutExtension + ".bck";
        string BackUpOfFileToReplace = actualLevel + filenameWithoutExtension + ".bck2";

        if (!File.Exists(actualLevel + Path.GetFileNameWithoutExtension(chuckFileSTD) + ".bck"))
        {
            File.Copy(@"" + actualLevel + chuckFileSTD, @"" + actualLevel + filenameWithoutExtension + ".bck");
            if (delete)
            {
                File.Delete(actualLevel + chuckFileSTD);
            }
        }else
        {
            if (delete) { 
            // Replace the file.
            File.Replace(OriginalFile, FileToReplace, BackUpOfFileToReplace);
            }else
            {
                File.Delete(BackUpOfFileToReplace);
                File.Move(FileToReplace, BackUpOfFileToReplace);
                File.Copy(OriginalFile, FileToReplace);
            }
            //Do the new bck
        }
        
    }
    void Start()
    {
        //createFolder("level1");
        //createFolder("level2");
        //writeChunkData("test");
        //readFile();
        //doBackupFile(false,"chunkData.ck");
        StartCoroutine(writeChunkData("test"));
    }
}

