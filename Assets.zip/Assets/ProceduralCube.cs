﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class ProceduralCube : MonoBehaviour {

    // This first list contains every vertex of the mesh that we are going to render
    public List<Vector3> newVertices = new List<Vector3>();

    // The triangles tell Unity how to build each section of the mesh joining
    // the vertices
    public List<int> newTriangles = new List<int>();

    // The UV list is unimportant right now but it tells Unity how the texture is
    // aligned on each polygon
    public List<Vector2> newUV = new List<Vector2>();


    // A mesh is made up of the vertices, triangles and UVs we are going to define,
    // after we make them up we'll save them as this mesh
    private Mesh mesh;
    private BoxCollider2D meshCollider;
    private MeshRenderer meshRender;
    // public Material newMaterialRef;

    //Array with trees we are going to combine
    public GameObject[] treesArray;
    //The object that is going to hold the combined mesh
    public GameObject combinedObj;
    // Use this for initialization
    void Start () {


        //Material
        
        Material newMat = Resources.Load("DEV_Orange", typeof(Material)) as Material;
        //Render
        meshRender = gameObject.AddComponent<MeshRenderer>();
        meshRender.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.TwoSided;
        meshRender.material = newMat;
        mesh = gameObject.AddComponent<MeshFilter>().mesh;




        //mesh = GetComponent<MeshFilter>().mesh;

        float x = transform.position.x;
        float y = transform.position.y;
        float z = transform.position.z;

        newVertices.Add(new Vector3(x, y, z));//0
        newVertices.Add(new Vector3(x + 1, y, z));//1
        newVertices.Add(new Vector3(x + 1, y - 1, z));//2
        newVertices.Add(new Vector3(x, y - 1, z));//3

        newVertices.Add(new Vector3(x, y , z + 1));//4
        newVertices.Add(new Vector3(x + 1, y , z + 1));//5

        newVertices.Add(new Vector3(x + 1, y - 1, z + 1));//6

        newVertices.Add(new Vector3(x , y - 1, z + 1));//7

        //Front
        newTriangles.Add(0);
        newTriangles.Add(1);
        newTriangles.Add(3);
        newTriangles.Add(1);
        newTriangles.Add(2);
        newTriangles.Add(3);
        //Top
        newTriangles.Add(0);
        newTriangles.Add(4);
        newTriangles.Add(1);
        newTriangles.Add(4);
        newTriangles.Add(5);
        newTriangles.Add(1);
        //Right
        newTriangles.Add(2);
        newTriangles.Add(1);
        newTriangles.Add(6);
        newTriangles.Add(1);
        newTriangles.Add(5);
        newTriangles.Add(6);
        //Back
        newTriangles.Add(6);
        newTriangles.Add(5);
        newTriangles.Add(7);
        newTriangles.Add(5);
        newTriangles.Add(4);
        newTriangles.Add(7);
        //Left
        newTriangles.Add(7);
        newTriangles.Add(4);
        newTriangles.Add(3);
        newTriangles.Add(4);
        newTriangles.Add(0);
        newTriangles.Add(3);
        //Bottom
        newTriangles.Add(7);
        newTriangles.Add(3);
        newTriangles.Add(6);
        newTriangles.Add(3);
        newTriangles.Add(2);
        newTriangles.Add(6);

        mesh.Clear();
        mesh.vertices = newVertices.ToArray();
        mesh.triangles = newTriangles.ToArray();
        mesh.RecalculateBounds();
        mesh.Optimize();
        mesh.RecalculateNormals();
        

        GameObject mesh2 = GameObject.CreatePrimitive(PrimitiveType.Cube);
        //GameObject mesh2 = GameObject.;
        mesh2.transform.position = new Vector3(0,3f,0);
        Mesh mesh3 = mesh2.GetComponent<MeshFilter>().mesh;
        //mesh3.
         CombineInstance[] combination = new CombineInstance[3];
        combination[0].mesh = mesh;
        combination[1].mesh = mesh2.GetComponent<MeshFilter>().mesh;
        //combination[1].transform = 
        combination[2].mesh = mesh3;
        mesh3.CombineMeshes(combination);
        
        for ( int i = 0; i < mesh3.vertices.Length;i++)
        {
            mesh3.vertices[i] *= 2;
            
            Debug.LogWarning("Vertex:"+mesh3.vertices[i].ToString());
            Debug.LogWarning("Normal:"+mesh3.normals[i].ToString());
        }
       // mesh3.vertices[]
        meshCollider = gameObject.AddComponent<BoxCollider2D>();
        gameObject.AddComponent<Rigidbody2D>();


        CombineTrees();


    }

    // Update is called once per frame
    void Update () {

      
    }

    void CombineTrees()
    {
        //Lists that holds mesh data that belongs to each submesh
        List<CombineInstance> leafList = new List<CombineInstance>();
        List<GameObject> treesArray = new List<GameObject>();
        //Loop through the array with trees
        for (int i = 0; i < 20; i++)
        {
            for(int e = 0; e < 26; e++)
            {
                treesArray.Add(GameObject.CreatePrimitive(PrimitiveType.Cube));
                treesArray[i].transform.localScale = new Vector3(0.5f, 0.5f, 0.5f);
                treesArray[i].transform.position = new Vector3(0 + e * 0.5f, 0 + i * 0.5f, 0);

                DestroyImmediate(treesArray[i].GetComponent<BoxCollider>());

                // treesArray[i].AddComponent<BoxCollider2D>();
                //treesArray[i].GetComponent<BoxCollider2D>().GetComponent<Collider2D>().
                GameObject currentTree = treesArray[i];
                //DestroyObject(treesArray[i]);


                //Deactivate the tree 
                currentTree.SetActive(false);

                //Get all meshfilters from this tree, true to also find deactivated children
                MeshFilter meshFilters = currentTree.GetComponent<MeshFilter>();

                CombineInstance combine = new CombineInstance();


                combine.mesh = meshFilters.mesh;
                combine.transform = meshFilters.transform.localToWorldMatrix;

                //Add it to the list of leaf mesh data
                leafList.Add(combine);

                
            }

            
        }
        foreach(GameObject objet in treesArray)
        {
           DestroyImmediate(objet);
        }
        
        

        Material newMat = Resources.Load("DEV_Orange", typeof(Material)) as Material;

        Mesh combinedLeafMesh = new Mesh();
        combinedLeafMesh.CombineMeshes(leafList.ToArray());

        GameObject final = new GameObject();
     
        final.AddComponent<MeshFilter>().mesh = combinedLeafMesh;
        final.AddComponent<MeshRenderer>().material = newMat;
        final.name = "asd";
        final.AddComponent<MeshCollider>();
      //  final.AddComponent<ColliderCreator>();
    }
}
